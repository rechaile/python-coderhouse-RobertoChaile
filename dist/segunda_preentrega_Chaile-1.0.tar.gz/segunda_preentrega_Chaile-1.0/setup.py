import setuptools

setuptools.setup(
    name="segunda_preentrega_Chaile",
    version="1.0",
    description="Este paquete contiene el programa referido a la segunda preentrega de Roberto Chaile para el curso de Python",
    author="Roberto Ezequiel Chaile",
    author_email="rechaile@gmail.com",
    
)